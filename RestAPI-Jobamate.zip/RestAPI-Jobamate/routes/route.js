const express = require('express');
const {
    getUsers,
    register,
    login
} = require("../Controller/user.js");

const router = express.Router();

router.get('/users', getUsers);
router.post('/register', register);
router.post('/login', login);

module.exports = router;